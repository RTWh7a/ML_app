# Import libraries
import base64
import io
import matplotlib.pyplot as plt
from lazypredict.Supervised import LazyClassifier
import numpy as np
import pandas as pd
import seaborn as sns
import streamlit as st
from sklearn.model_selection import train_test_split

# ___________________________________
# Model Build
# ___________________________________
# Page layout
st.set_page_config(
    page_title="Hyperparameter Tuning", page_icon=":tada:", layout="wide"
)


# ___________________________________
def build_model(df):
    X = df.iloc[:, :-1]  # Using all columns except the last one (target)
    y = df.iloc[:, -1]  # Using the last column

    st.markdown("### 1.2. Data splits")

    # Using columns to lay out the shapes nicely
    col1, col2 = st.columns(2)
    with col1:
        st.write("X Features Shape (Training Pool):")
        st.info(X.shape)
    with col2:
        st.write("y Target Shape (Labels Pool):")
        st.info(y.shape)

    # Split the dataset
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    st.markdown("### 1.3. Variable details")
    st.write("**X_Variables:**")
    st.info(list(X.columns))
    st.write("**y_variable:**")
    st.info(y.name)

    st.markdown("### 1.4. Model Building")

    # Initialize LazyClassifier
    clf = LazyClassifier(verbose=0, ignore_warnings=True, custom_metric=None)

    # 🔥 FIXED: Correctly pass train and test sets into a single fit call
    with st.spinner("Training up to 30 models... Please wait."):
        models, predictions = clf.fit(X_train, X_test, y_train, y_test)

    # Performance Layout using Columns
    st.subheader("2. Model Performance Summary")
    st.dataframe(models)

    # Build dataframe for plotting
    # LazyPredict returns 'Accuracy', 'Balanced Accuracy', 'ROC AUC', 'F1 Score'
    df_plot = models.reset_index().melt(
        id_vars="Model", var_name="Metric", value_name="Score"
    )

    # Filter out Time Taken so it doesn't skew the 0-1 scale metric plot
    df_plot = df_plot[df_plot["Metric"] != "Time Taken"]

    # ------------Plot----------------#
    st.subheader("3. Plot the Models Performance")

    # 🔥 FIXED: Removed the invalid 'with st.markdown' context wrapper
    fig, ax1 = plt.subplots(figsize=(12, 10))
    sns.set_theme(style="whitegrid")

    sns.barplot(data=df_plot, y="Model", x="Score", hue="Metric", ax=ax1)
    ax1.set(xlim=(0, 1))

    plt.tight_layout()
    st.pyplot(fig)


# ___________________________________#
st.write("""
# The Model Building App
         
is an interactive web application built using Streamlit that allows users to build and evaluate machine learning models
with ease. The app provides a user-friendly interface for data preprocessing, model selection, and performance
evaluation, making it accessible to both beginners and experienced data scientists. Users can upload their data.
It variables, and model parameters, and the app will handle the rest, providing insights into model performance through
vriase visualizations and metrics. It Mades by Rafat Waheed Abdo, Linked in [Rafat Waheed Abdo](https://www.linkedin.com/in/rafaat-waheed-8bba22290)
""")

# ______________________________________#
# Sidebar UI Setup
st.sidebar.header("1. Upload your data")
upload_file = st.sidebar.file_uploader("Upload your input CSV file", type=["csv"])

# Setup sidebar inputs first so they are available globally
st.sidebar.header("2. Model Parameters")
test_size = st.sidebar.slider(
    "Test set size (percentage)", 0.1, 0.5, 0.2, step=0.05
)
random_state = st.sidebar.slider("Random state", 0, 100, 42)

# --- Check file execution status ---
if upload_file is not None:
    df = pd.read_csv(upload_file)
    st.sidebar.markdown("**1.1. Preview of dataset**")
    st.sidebar.dataframe(df.head())

    # Triggering the model execution
    build_model(df)
else:
    st.sidebar.info("Awaiting CSV file to be uploaded.")
    st.sidebar.info("Currently only CSV files are supported.")
    st.sidebar.markdown("**Example CSV file format:**")
    st.sidebar.markdown("""
     | Feature1 | Feature2 | Target | 
     |----------|----------|--------|""")