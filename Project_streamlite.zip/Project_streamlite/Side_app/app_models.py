import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from lazypredict import LazyClassifier
import seaborn as sns
import altair as alt
import plotly.express as px
#########################
#prepare the interferance
#########################
st.set_page_config(page_title='The Machine Learning App',layout='centered')

#######################
#Model Build
#######################
def build_model(df):
    X = df.iloc[:, :-1]
    y = df.iloc[:, -1]

    st.markdown('**1.2. Data Splits**')
    col1, col2 = st.columns(2)
    col1.write('X shape')
    col1.info(X.shape)
    col2.write('Y shape')
    col2.info(y.shape)
    
    st.markdown('**1.3. Variable details:**')
    st.write('X variables')
    st.info(list(X.columns))
    st.write('Y variable')
    st.info(y.name)

    # Data split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Initialize and fit LazyClassifier
    clf = LazyClassifier(verbose=0, ignore_warnings=True, custom_metric=None)
    models, predictions = clf.fit(X_train, X_test, y_train, y_test)

    st.subheader('2. Model Performance')
    st.dataframe(models)

    #######################
    # Plot the results
    #######################
    st.subheader('Plot of Model Performance')

    # IMPORTANT: LazyPredict puts model names in the index. We must move them to a column.
    plot_df = models.reset_index().rename(columns={'index': 'Model'})

    # 2. Identify metric columns automatically (everything except Model and Time Taken)
    # We also filter out any columns that aren't numeric to avoid Plotly errors
    metric_cols = [col for col in plot_df.columns if col not in ['Model', 'Time Taken']]
    
    # 3. Reshape the data for Plotly (Wide to Long)
    df_melted = plot_df.melt(
        id_vars=['Model', 'Time Taken'], 
        value_vars=metric_cols, 
        var_name='Metric', 
        value_name='Score'
    )
    
    # 4. Create Interactive Plotly Chart
    fig = px.bar(
        df_melted,
        x='Model',
        y='Score',
        color='Time Taken',       # Color intensity based on time
        facet_col='Metric',       # One chart per metric (Accuracy, F1, etc.)
        facet_col_wrap=2,         # 2 charts per row
        title="LazyPredict Model Comparison",
        labels={'Score': 'Value', 'Time Taken': 'Seconds'},
        color_continuous_scale='Blues', # Clean blue gradient for web
        height=800
    )
    
    # Formatting for web display
    fig.update_layout(xaxis_tickangle=-45)
    fig.for_each_annotation(lambda a: a.update(text=a.text.split("=")[-1])) # Cleans up titles
    
    # 5. Display in Streamlit
    st.plotly_chart(fig, use_container_width=True)

    

##############
#Upload files
##############   
  
with st.sidebar.header('Upload The Data'):
    upload_file=st.sidebar.file_uploader('Upload Youer File')
    st.markdown('**Test the data and Models performance**')

if upload_file is not None:
    df=pd.read_csv(upload_file)
    st.dataframe(df)
    build_model(df)
else:
    pass